﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FitnessCalculator.Contracts
{
    public interface IReader
    {
        string ReadLine();

    }
}
